from setuptools import setup, find_packages
setup(
    name='python_email_client',
    version='0.0.8',
    packages=find_packages()
)